/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.home;

/**
 *
 * @author pmp
 */
public class HomeBean_1_1_1 {
    private String assignnum;
    private String assigndate;
    private String projnum;
    private String empnum;
    private String billph;
    
    //constructor

    public HomeBean_1_1_1(String assignnum, String assigndate, String projnum, String empnum, String billph) {
        this.assignnum = assignnum;
        this.assigndate = assigndate;
        this.projnum = projnum;
        this.empnum = empnum;
        this.billph = billph;
    }
    
    // getter and setter methods

    public String getassignnum() {
        return assignnum;
    }

    public void setassignnum(String assignnum) {
        this.assignnum = assignnum;
    }

    public String getassigndate() {
        return assigndate;
    }

    public void setassigndate(String assigndate) {
        this.assigndate = assigndate;
    } 
    
    public String getprojnum() {
        return projnum;
    }

    public void setprojnum(String projnum) {
        this.projnum = projnum;
    }
    
    public String getempnum() {
        return empnum;
    }

    public void setempnum(String empnum) {
        this.empnum = empnum;
    }
    
    public String getbillph() {
        return billph;
    }

    public void setbillph(String billph) {
        this.billph = billph;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.home;

/**
 *
 * @author pmp
 */
public class HomeBean_1 {
    private String jobcode;
    private String jobclass;
    
    //constructor

    public HomeBean_1(String jobcode, String jobclass) {
        this.jobcode = jobcode;
        this.jobclass = jobclass;
    }
    
    // getter and setter methods

    public String getjobcode() {
        return jobcode;
    }

    public void setjobcode(String jobcode) {
        this.jobcode = jobcode;
    }

    public String getjobclass() {
        return jobclass;
    }

    public void setjobclass(String jobclass) {
        this.jobclass = jobclass;
    } 
    
}

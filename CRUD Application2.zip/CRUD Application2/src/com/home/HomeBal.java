/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.home;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.*;

/**
 *
 * @author pmp
 */
public class HomeBal {
    
    //method for load read data from employee...
    public List<HomeBean> loadData() {
        List<HomeBean> list = new ArrayList<HomeBean>();
        try{
            String query = "select * from employee";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String empnum = rs.getString("empnum");
                String lname = rs.getString("lname");
                String fname = rs.getString("fname");
                String empcode = rs.getString("empcode");
                String jobcode = rs.getString("jobcode");
                HomeBean bean = new HomeBean(empnum, lname, fname, empcode, jobcode);
                list.add(bean);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
        return list;
    }
    
    //method for inserting data

    public void insert(HomeBean homeBean){
        
        try{
            String query = "insert into employee values (?, ?, ?, ?, ?)";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ps.setString(1, homeBean.getempnum());
            ps.setString(2, homeBean.getlname());
            ps.setString(3, homeBean.getfname());
            ps.setString(4, homeBean.getempcode());
            ps.setString(5, homeBean.getjobcode());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "A record has been inserted...");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
    }
    
    //method for updating data
    public HomeBean returnAllDataTextField(String empnum){
        HomeBean bean = null;
        try {
            String query = "select * from employee where empnum = "+empnum;
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String empnums = rs.getString("empnum");
                String lname = rs.getString("lname");
                String fname = rs.getString("fname");
                String empcode = rs.getString("empcode");
                String jobcode = rs.getString("jobcode");
                bean = new HomeBean(empnums, lname, fname, empcode, jobcode);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
        return bean;
    }
    
    public void updateData(HomeBean bean) {
        try {
            String query = "update employee set lname = ?, fname = ?, empcode = ?, jobcode = ? where empno = ?";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ps.setString(1, bean.getfname());
            ps.setString(2, bean.getlname());
            ps.setString(3, bean.getempcode());
            ps.setString(4, bean.getjobcode());
            ps.setString(5, bean.getempnum());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "A record has been updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
    }
    
    public void deleteRecord(String empnum) {
        try {
            String query = "delete from employee where empnum = ?";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ps.setString(1, empnum);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "A record has been deleted...");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
    }
}

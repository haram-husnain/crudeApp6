/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.home;

import javax.swing.JOptionPane;
import java.sql.*;
import java.util.*;

/**
 *
 * @author pmp
 */
public class HomeBal_1 {
    
    //method for load read data from employee...
    public List<HomeBean_1> loadData() {
        List<HomeBean_1> list = new ArrayList<HomeBean_1>();
        try{
            String query = "select * from job";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String jobcode = rs.getString("jobcode");
                String jobclass = rs.getString("jobclass");
                HomeBean_1 bean_1 = new HomeBean_1(jobcode, jobclass);
                list.add(bean_1);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
        return list;
    }
    
    //method for inserting data

    public void insert(HomeBean_1 homeBean_1){
        
        try{
            String query = "insert into job values (?, ?)";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ps.setString(1, homeBean_1.getjobcode());
            ps.setString(2, homeBean_1.getjobclass());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "A record has been inserted...");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
    }
    
    //method for updating data
    public HomeBean_1 returnAllDataTextField(String jobcode){
        HomeBean_1 bean_1 = null;
        try {
            String query = "select * from job where jobcode = "+jobcode;
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String jobcodes = rs.getString("jobcode");
                String jobclass = rs.getString("jobclass");
                bean_1 = new HomeBean_1(jobcodes, jobclass);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
        return bean_1;
    }
    
    public void updateData(HomeBean_1 bean_1) {
        try {
            String query = "update job set jobclass = ? where jobcode = ?";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ps.setString(1, bean_1.getjobclass());
            ps.setString(2, bean_1.getjobcode());
            
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "A record has been updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
    }
    
    public void deleteRecord(String jobcode) {
        try {
            String query = "delete from job where jobcode = ?";
            PreparedStatement ps = com.databaseCon.DB.con.prepareStatement(query);
            ps.setString(1, jobcode);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(null, "A record has been deleted...");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, ""+e);
        }
    }
}

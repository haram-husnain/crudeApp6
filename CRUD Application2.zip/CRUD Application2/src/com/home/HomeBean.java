/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.home;

/**
 *
 * @author pmp
 */
public class HomeBean {
    private String empnum;
    private String lname;
    private String fname;
    private String empcode;
    private String jobcode;
    
    //constructor

    public HomeBean(String empnum, String lname, String fname, String empcode, String jobcode) {
        this.empnum = empnum;
        this.lname = lname;
        this.fname = fname;
        this.empcode = empcode;
        this.jobcode = jobcode;
    }
    
    // getter and setter methods

    public String getempnum() {
        return empnum;
    }

    public void setempnum(String empnum) {
        this.empnum = empnum;
    }

    public String getlname() {
        return lname;
    }

    public void setlname(String lname) {
        this.lname = lname;
    }

    public String getfname() {
        return fname;
    }

    public void setfname(String fname) {
        this.fname = fname;
    }

    public String getempcode() {
        return empcode;
    }

    public void setempcode(String empcode) {
        this.empcode = empcode;
    }

    public String getjobcode() {
        return jobcode;
    }

    public void setjobcode(String jobcode) {
        this.jobcode = jobcode;
    }
    
    
}

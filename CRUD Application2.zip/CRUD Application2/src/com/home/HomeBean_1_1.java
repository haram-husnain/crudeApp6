/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.home;

/**
 *
 * @author pmp
 */
public class HomeBean_1_1 {
    private String projnum;
    private String projname;
    
    //constructor

    public HomeBean_1_1(String projnum, String projname) {
        this.projnum = projnum;
        this.projname = projname;
    }
    
    // getter and setter methods

    public String getprojnum() {
        return projnum;
    }

    public void setprojnum(String projnum) {
        this.projnum = projnum;
    }

    public String getprojname() {
        return projname;
    }

    public void setprojname(String projname) {
        this.projname = projname;
    } 
    
}
